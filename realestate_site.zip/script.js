function calcMortgage(){
  let price = Number(document.getElementById("price").value);
  let down = Number(document.getElementById("down").value);
  let rate = Number(document.getElementById("rate").value)/100/12;
  let years = Number(document.getElementById("years").value)*12;
  if(price<=0||down<0||rate<=0||years<=0){alert('Проверьте данные');return;}
  let loan = price-down;
  if(loan<=0){alert('Первоначальный взнос не может быть больше стоимости');return;}
  let monthly = loan*(rate*Math.pow(1+rate,years))/(Math.pow(1+rate,years)-1);
  let overpay = monthly*years - loan;
  document.getElementById('monthly').innerText = 'Ежемесячный платёж: ' + Math.round(monthly).toLocaleString('ru-RU') + ' ₽';
  document.getElementById('overpay').innerText = 'Переплата банку: ' + Math.round(overpay).toLocaleString('ru-RU') + ' ₽';
  document.getElementById('result').style.display='block';
  document.getElementById('applyWa').href = 'https://wa.me/79855765769?text=' + encodeURIComponent('Запрос на подбор ипотечной программы. Платёж: ' + Math.round(monthly).toLocaleString('ru-RU') + ' ₽. Контакт:');
}

function nextQ(n){
  document.getElementById('q'+n).style.display='none';
  document.getElementById('q'+(n+1)).style.display='block';
}
function prevQ(n){
  document.getElementById('q'+n).style.display='none';
  document.getElementById('q'+(n-1)).style.display='block';
}
function sendQuiz(){
  let loc=document.getElementById('q_location').value;
  let bud=document.getElementById('q_budget').value;
  let name=document.getElementById('q_name').value;
  let phone=document.getElementById('q_phone').value;
  if(!loc||!bud||!name||!phone){alert('Заполните все поля');return;}
  let msg='Новая заявка: '+name+' '+phone+' Локация: '+loc+' Бюджет: '+bud;
  window.open('https://wa.me/79855765769?text='+encodeURIComponent(msg),'_blank');
}
